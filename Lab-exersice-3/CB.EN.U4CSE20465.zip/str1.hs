main = do
    putStrLn "Enter your address"
    address <- getLine
    putStrLn ("Your address is " ++ address)